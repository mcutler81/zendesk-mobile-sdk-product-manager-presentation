//
//  ViewController.swift
//  SDKTest
//
//  Created by MTTUser on 02/10/2017.
//
//

import UIKit
import ZendeskSDK




class ViewController: UIViewController {
    
 
    @IBAction func buttonPressed(_ sender: UIButton) {
        
        // Create a Content Model to pass in
        let helpCenterContentModel = ZDKHelpCenterOverviewContentModel.defaultContent()
        // Show Help Center
        ZDKHelpCenter.pushOverview(self.navigationController, with:helpCenterContentModel)
    }
    
}
